
// NS Lat daemon , thread which uses msgQ and db references.

#include <ldns/ldns.h>
#include <mysql++.h>
#include <connection.h>
#include <noexceptions.h>
#include <options.h>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <chrono>
#include <ctime>
#include <chrono>
#include <stdlib.h>
#include <vector>

class nsQuery {
public:
	//constructor
	nsQuery (std::vector<std::string> servers, std::string dbServer);

	//destructor
	~nsQuery ();

	//work done to perform NS queries for relevant ns servers
	void nsDoquery (int freq);

	//clear db
	void nsDbClear (void);

	//print stats 
	void nsDbStats (void);

private:
	// top 10 websites 
	std::vector <std::string> mNameservers;

	// mysql db server info
	std::string mDbServer;

	//private API to query one server at a time . 
	void nsQueryServer (std::string server, int &latency, std::time_t &time);

	//log results of a server and query 
	void nsLogQueryData (std::string server, int latency, std::time_t time);
};
