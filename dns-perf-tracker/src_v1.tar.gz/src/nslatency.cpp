
#include <string.h>
#include "nslatency.h"
#include "nslatencyd.h"

void nslatency_usage (void) {
#define NSLATENCY_COMMAND "nslatency COMMAND [OPTION]"
#define NSLATENCY_DESCRIPTION "Nslatency is a program to periodically sends DNS queries to the name servers of the top 10 sites on the web (according to Alexa) and store the latency values in a MySQL table. The frequency of queries should be specified by the user on command line. Besides the time series values, it keeps track of some statistics about each domain in the MySQL database."
	cout << "NAME" << endl;
	cout << "\tnslatency - query top 10 name servers to measure their performance" << endl << endl;
	cout << "SYNOPSIS" << endl;
	cout << "\t" << NSLATENCY_COMMAND << endl << endl;
	cout << "DESCRIPTION" << endl;
	cout << NSLATENCY_DESCRIPTION << endl << endl;
	cout << "ARGUMENTS" << endl;
	cout << "\tnslatency start (freq)" << endl;
	cout << "\tnslatency stop" << endl;
	cout << "\tnslatency cleardb" << endl;
	cout << "\tnslatency stats" << endl;
	cout << endl << endl;
}

bool debug_mode = false;
//class ParseInput {
//	
//
//};

/*
//TODO
1. move the command parsing logic to its class 
2.test input string for number to string conversions
*/
int 
main(int argc, char *argv[]) {
	char * command = NULL;
	int freq = NSLATENCY_FREQ_DEFAULT;
	NslatencyCmd cmd = Invalid;

	if (argc != 3 && argc != 2) {
		goto error;
	}

	//check the command 
	command = argv[1];
	if (strcmp (command, NSLATENCY_CMD_STR_START) == 0) {
		//nslatency arguments check 
		if (argc == 3) {
			stringstream freqText (argv[2]);
			if ( !(freqText >> freq) ) {
				goto error;
			}
			if (debug_mode) {
				cout << "start with freq: " << freq << endl;
			}
		} 
		cmd = Start;
		if (debug_mode) {
			cout << "command : nslatency start " << freq << endl;
		}
		nslatencyd(freq);
	} else if (strcmp (command, NSLATENCY_CMD_STR_STOP) == 0) {
		if (debug_mode) {
			cout << "command : nslatency stop: " << freq << endl;
		}
		cmd = Stop;
	} else if (strcmp (command, NSLATENCY_CMD_STR_CLEARDB) == 0) {
		if (debug_mode) {
			cout << "command : nslatency cleardb: " << freq << endl;
		}
		cmd = Cleardb;
		NsLogClearDb ();
	} else if (strcmp (command, NSLATENCY_CMD_STR_STATS) == 0) {
		if (debug_mode) {
			cout << "command : nslatency stats: " << freq << endl;
		}
		cmd = Stats;
		NsLogStats();
	} else {
		goto error;
	}
	return 0;

error:
	nslatency_usage();
	return -1;
}
