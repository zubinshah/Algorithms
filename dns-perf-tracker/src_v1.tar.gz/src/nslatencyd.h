
// NS latency daemon , thread which uses msgQ and db references.


#include <iostream>
#include <iomanip>
#include <sstream>
#include <ldns/ldns.h>
#include <mysql++.h>
#include <connection.h>
#include <noexceptions.h>
#include <options.h>
#include <chrono>
#include <ctime>

int NsLogClearDb(void);
int NsLogStats (void);
int NsLog (std::time_t time, int latency);
void nslatencyd (int freq);
