

// NS query thread class implementation


class QueryThread {
public:
	//public constructor
	QueryThread (const char *ThreadName, int freq);

	//destructor
	~QueryThread(void);

	std::thread::id CreateThread (int freq);


private:
	//thread handle which is stored
	//message queue handle
	//freq 
	std::thread * mThread;
	std::queue<int> msgQueue;



};
