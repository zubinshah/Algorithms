// zubin.shah@gmail.com
// 2018 - nslat utility to perform dns queries
#include <iomanip>
#include <iostream>
#include <sstream>

using namespace std;

//global defines 
#define NSLATENCY_FREQ_DEFAULT 10

typedef enum {
	Start = 1, 
	Stop = 2, 
	Cleardb = 3,
	Stats = 4,
	Invalid = 5
} NsLatCmd;

//command string options
#define NSLATENCY_CMD_STR_START 	"start"
#define NSLATENCY_CMD_STR_STOP		"stop"
#define NSLATENCY_CMD_STR_CLEARDB 	"cleardb"
#define NSLATENCY_CMD_STR_STATS		"stats"

int main(int argc, char *argv[]);
