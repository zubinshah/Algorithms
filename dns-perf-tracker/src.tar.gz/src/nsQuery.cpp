// zubin.shah@gmail.com
// 2018 - nslat utility to perform dns queries

// NS lat daemon , thread which uses msgQ and db references.
#include "nsQuery.h"
#include <thread>
using namespace std;

nsQuery::nsQuery (std::vector <std::string> servers, std::string dbServer) :
		mNameservers(servers), mDbServer(dbServer) {
	//for (int i = 0; i < servers.size(); i++) {
	//	cout << mNameservers[i] << endl;
	//}
	//cout << mDbServer << endl;
}

nsQuery::~nsQuery () {
	
}

void nsQuery::nsDoquery (int freq) {
	while (true) {

		//query all name servers and store latency 
		for (int i = 0; i < mNameservers.size(); i++) {
			int latency = 0;
			std::time_t time(0);
			nsQueryServer(mNameservers[i], latency, time);	
			nsLogQueryData(mNameservers[i], latency, time);
		}
	
		//sleep this routine for *freq* seconds 
		
		//TBD LATER
		//this causes a blocking call. however from the requirements there is 
		//no clear mention if this tool/cli command may or may not need to be blocking
		//MY OPTIMIZATION should involve making this nsDoquery utility as a daemon or 
		//running into background thread. However , does not impact functionality 
		//sleep for "freq" seconds
		std::this_thread::sleep_for(std::chrono::seconds(freq));
	}
}

void nsQuery::nsQueryServer (std::string server, int &latency, std::time_t &time) {
    char *serv = NULL;

    int i;
	int 		int_type;
	uint16_t 	qbuf;
	bool 		qrandom;
	uint16_t	qport;
	uint32_t	serial = 0;
	ldns_rr_list	*cmdline_rr_list = NULL;
	ldns_rdf 	*src_rdf = NULL;
    char 		*src = NULL;
	bool		qusevc;
	bool		qfallback;
	uint8_t		qfamily;
	bool		qdnssec;
    ldns_resolver   *cmdline_res = NULL; /* only used to resolv @name names */
	char		*resolv_conf_file = NULL;
	ldns_rdf	*cmdline_dname = NULL;
	ldns_rdf 	*serv_rdf;
	ldns_rr_list	*key_list = ldns_rr_list_new(); 
	src = NULL;
	qdnssec = false;
	qfamily = LDNS_RESOLV_INETANY;
	qfallback = false;
	qusevc = false;
	qport = LDNS_PORT;
	qrandom = true;
	qbuf = 0;
    ldns_resolver *res = NULL;
	ldns_status	status;
    ldns_rr_type    type = LDNS_RR_TYPE_A;
    ldns_rr_type    clas = (ldns_rr_type) LDNS_RR_CLASS_IN;
    ldns_pkt *pkt=NULL;
    ldns_pkt *qpkt=NULL;
	uint16_t qflags = LDNS_RD;

	//storing current time stamp 
	time = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
	
	// Randomize the nameserver's name to avoid using local cache.
	// however this approach is not 100% guaranteed to avoid this, if within two
	// subsequent tries the randomization may cause same server string. 

	srand (time);
	std::string tServer = std::to_string(rand() % 100000) + server;

	//converting to c-style char* for using with ldns library
    const char *name = tServer.c_str();
	if (!name) {
		/* act like dig and use for . NS */
		name = ".";
		int_type = 0;
		type = LDNS_RR_TYPE_NS;
	}

    ldns_rdf *qname = ldns_dname_new_frm_str(name);
    if (!qname) {
        printf("Error: error in making qname\n");
    }

	/* set the nameserver to use */
	if (!serv) {
		/* no server given -- make a resolver from /etc/resolv.conf */
		status = ldns_resolver_new_frm_file(&res, NULL);
		if (status != LDNS_STATUS_OK) {
			printf("WARNING: Could not create a resolver structure: %s (%s)\n"
				   "Try drill @localhost if you have a resolver running on your machine.",
				   ldns_get_errorstr_by_id(status), resolv_conf_file);
            return;
		}
	} else {
		res = ldns_resolver_new();
		if (!res || strlen(serv) <= 0) {
			printf("WARNING: Could not create a resolver structure");
			return ;
		}
		/* add the nameserver */
		serv_rdf = ldns_rdf_new_frm_str(LDNS_RDF_TYPE_A, serv);
		if (!serv_rdf) {
			/* try to resolv the name if possible */
			status = ldns_resolver_new_frm_file(&cmdline_res, resolv_conf_file);

			if (status != LDNS_STATUS_OK) {
				printf("ERROR: %s", "@server ip could not be converted");
			}
			ldns_resolver_set_dnssec(cmdline_res, qdnssec);
			ldns_resolver_set_ip6(cmdline_res, qfamily);
			ldns_resolver_set_fallback(cmdline_res, qfallback);
			ldns_resolver_set_usevc(cmdline_res, qusevc);
			ldns_resolver_set_source(cmdline_res, src_rdf);
			cmdline_dname = ldns_dname_new_frm_str(serv);
			cmdline_rr_list = ldns_get_rr_list_addr_by_name(
						cmdline_res, 
						cmdline_dname,
						LDNS_RR_CLASS_IN,
						qflags);
			ldns_rdf_deep_free(cmdline_dname);
			if (!cmdline_rr_list) {
				/* This error msg is not always accurate */
				printf("ERROR: %s `%s\'", "could not find any address for the name:", serv);
			} else {
				if (ldns_resolver_push_nameserver_rr_list(
						res, 
						cmdline_rr_list
					) != LDNS_STATUS_OK) {
					printf("ERROR: %s", "pushing nameserver");
				}
			}
		} else {
			if (ldns_resolver_push_nameserver(res, serv_rdf) != LDNS_STATUS_OK) {
				printf("ERROR: %s", "pushing nameserver");
			} else {
				ldns_rdf_deep_free(serv_rdf);
			}
		}
	}

	if (!name && !serv) {
		time = 0;
		latency = 0;
        return ;
	}

    status = ldns_resolver_query_status(
                &pkt,
                res,
                qname,
                type,
                (ldns_rr_class) clas,
                qflags);

    if ((int) status) {
        printf("ERROR: sending query %s\n", ldns_get_errorstr_by_id(status));
    }

    if (!pkt)  {
        printf("No packet received");
    } else {
        //printf("Packet received \n");
		if (ldns_rr_list_rr_count(key_list) > 0) {
			//printf("rr_list_count > 0\n");
			ldns_rr_list *rrset_verified;
			uint16_t key_count;
			rrset_verified = ldns_pkt_rr_list_by_name_and_type(
													pkt, qname, type, 
													LDNS_SECTION_ANY_NOQUESTION);
			if (type == LDNS_RR_TYPE_ANY) {
			}
			(void) key_count;
		}
		latency = ldns_pkt_querytime(pkt);
		//printf("rr_list_count = 0, query_time: %d\n", ldns_pkt_querytime(pkt));
		ldns_pkt_free(pkt); 
	}
    return;
}

void nsQuery::nsLogQueryData (std::string server, int latency, std::time_t time) {
	mysqlpp::Connection conn;
	//conn.connect(NULL, "localhost", "root", "root", 0);
	conn.connect(NULL, mDbServer.c_str(), "root", "root", 0);
    conn.enable_exceptions();
	conn.set_option(new mysqlpp::MultiStatementsOption(true));

	try {
		conn.create_db(server);
		conn.select_db(server);
	} catch (const mysqlpp::BadQuery& er) {
		conn.select_db(server);
	}

	mysqlpp::Query query = conn.query();
	query << "CREATE TABLE IF NOT EXISTS latency" << 
			 "(id INT(10) NOT NULL auto_increment, timestamp INT(32), latency INT(10)," << 
			 "PRIMARY KEY (id));";
	query.execute();
	
	query << "INSERT INTO latency " << 
			 "VALUES (NULL, " << to_string(time) << ", " << to_string(latency) << ");";
	//cout << query << endl;
	query.execute();
}

void nsQuery::nsDbClear (void) {
	//nsLogStats();
	mysqlpp::Connection conn;
	conn.connect(NULL, mDbServer.c_str(), "root", "root", 0);
    conn.enable_exceptions();
	conn.set_option(new mysqlpp::MultiStatementsOption(true));

	for (int i = 0; i < mNameservers.size(); i++) {
		try {
			conn.drop_db(mNameservers[i]);
		} catch (const mysqlpp::BadQuery &er) {
			cout << "Error: Clearing Db " << mNameservers[i] << endl;
		}
	}
}

void nsQuery::nsDbStats (void) {
	mysqlpp::Connection conn;
	conn.connect(NULL, "localhost", "root", "root", 0);
    conn.enable_exceptions();
	conn.set_option(new mysqlpp::MultiStatementsOption(true));

	cout << "(DNS) - NS Query Statistics" << endl;
	
	for (int i = 0; i < mNameservers.size(); i++) {
		try {
			conn.select_db(mNameservers[i]);
		} catch (const mysqlpp::BadQuery& er) {
			cout << "Databased does not exist or has been cleared" << endl;
			conn.select_db(mNameservers[i]);
		}

		mysqlpp::Query query = conn.query();
		query << "SELECT * from latency;";
		mysqlpp::StoreQueryResult res = query.store();
		if (res) {
			int avg = 0;
			for (size_t i = 0; i < res.num_rows(); i++) {
				std::time_t time = res[i][1];
				char *str = ctime(&time);
				str[strlen(str)-1] = NULL;
				int latency = res[i][2];
				avg += latency;
			}
			avg = avg/res.num_rows();

			int stddev = 0;
			for (size_t i = 0; i < res.num_rows(); i++) {
				int latency = res[i][2] - avg;
				stddev += (latency*latency);
			}
			stddev = stddev/res.num_rows();

			cout << "DNS: " << mNameservers[i] << endl;
			cout << "Queries " << res.num_rows() << endl;
			cout << "Mean " << avg << " msec., ";
			cout << "Mean (SD) " << stddev << endl;
	 		//cout << mNameservers[i] << endl;
			//cout << "Number of queries:" << res.num_rows() << endl;
			//cout << "Average latency:" << avg << " msec" << endl;
			//cout << "Standard Deviation:" << stddev << endl;

			std::time_t ftime = res[0][1];
			char *first = ctime(&ftime);
			first[strlen(first)-1] = NULL;
			//cout << "First Query: " << first << endl;
			cout << "First@" << first << endl;


			std::time_t ltime = res[res.num_rows()-1][1];
			char *last = ctime(&ltime);
			last[strlen(last)-1] = NULL;
			//cout << "Last Query: " << last << endl;
			cout << "Last@" << last << endl << endl;
		} else {
			cout << "Failed to get the latency table" << endl;
		}

	}
}
#if 0
int NsLogStats (void) {
	mysqlpp::Connection conn;
	conn.connect(NULL, "localhost", "root", "root", 0);
    conn.enable_exceptions();
	conn.set_option(new mysqlpp::MultiStatementsOption(true));

	try {
		conn.select_db(TESTDB_NAME);
	} catch (const mysqlpp::BadQuery& er) {
		cout << "Databased does not exist or has been cleared" << endl;
		conn.select_db(TESTDB_NAME);
	}

	mysqlpp::Query query = conn.query();
	query << "SELECT * from latency;";
	mysqlpp::StoreQueryResult res = query.store();
	if (res) {
		int avg = 0;
		for (size_t i = 0; i < res.num_rows(); i++) {
			std::time_t time = res[i][1];
			char *str = ctime(&time);
			str[strlen(str)-1] = NULL;
			int latency = res[i][2];
			avg += latency;
		}
		avg = avg/res.num_rows();

		int stddev = 0;
		for (size_t i = 0; i < res.num_rows(); i++) {
			int latency = res[i][2] - avg;
			stddev += (latency*latency);
		}
		stddev = stddev/res.num_rows();

		cout << "Number of queries:" << res.num_rows() << endl;
		cout << "Average latency:" << avg << " msec" << endl;
		cout << "Standard Deviation:" << stddev << endl;

		std::time_t ftime = res[0][1];
		char *first = ctime(&ftime);
		first[strlen(first)-1] = NULL;
		cout << "First Query: " << first << endl;

		std::time_t ltime = res[res.num_rows()-1][1];
		char *last = ctime(&ltime);
		last[strlen(last)-1] = NULL;
		cout << "Last Query: " << last << endl;

		cout << endl;
	} else {
		cout << "Failed to get the latency table" << endl;
	}
}
#endif 
#if 0
int NsLog (std::time_t time , int latency) {
	mysqlpp::Connection conn;
	conn.connect(NULL, "localhost", "root", "root", 0);
    conn.enable_exceptions();
	conn.set_option(new mysqlpp::MultiStatementsOption(true));

	try {
		conn.create_db(TESTDB_NAME);
		conn.select_db(TESTDB_NAME);
	} catch (const mysqlpp::BadQuery& er) {
		conn.select_db(TESTDB_NAME);
		//conn.connect(TESTDB_NAME, "localhost", "root", "root", 0);
	}

	mysqlpp::Query query = conn.query();
	query << "CREATE TABLE IF NOT EXISTS latency" << 
			 "(id INT(10) NOT NULL auto_increment, timestamp INT(32), latency INT(10)," << 
			 "PRIMARY KEY (id));";
	query.execute();
/*
CREATE TABLE IF NOT EXISTS `tblsample` (

  `id` int(11) NOT NULL auto_increment,   
    `recid` int(11) NOT NULL default '0',       
	  `cvfilename` varchar(250)  NOT NULL default '',     
	    `cvpagenumber`  int(11) NULL,     
		  `cilineno` int(11)  NULL,    
		    `batchname`  varchar(100) NOT NULL default '',
			  `type` varchar(20) NOT NULL default '',    
			    `data` varchar(100) NOT NULL default '',
				   PRIMARY KEY  (`id`)

				   );

*/
	//mysqlpp::Query query = conn.query();
	query << "INSERT INTO latency " << 
			 "VALUES (NULL, " << to_string(time) << ", " << to_string(latency) << ");";
	cout << query << endl;
	query.execute();

	//query << "SELECT * from latency;";
	//mysqlpp::StoreQueryResult res = query.store();
	//if (res) {
	//	for (size_t i = 0; i < res.num_rows(); i++) {
	//		cout << "(" << res[i][0] << "," << res[i][1] << ")"; 
	//	}
	//} else {
	//	cout << "Failed to get the latency table" << endl;
	//}
	//
	//conn.drop_db(TESTDB_NAME);

	//conn.drop_db(TESTDB_NAME);
	//mysqlpp::Query query = conn.query();
	//query << 
	//		 "DROP TABLE IF EXISTS latency_table; " <<
	//		 "CREATE TABLE latency_table(id INT); " <<
	//		 "INSERT INTO latency_table VALUES(100); " <<
	//		 "UPDATE latency_table SET id=20 WHERE id=10; " <<
	//		 "SELECT * FROM latency_table; " <<
	//		 "DROP TABLE latency_table";
	//cout << "Multi-query: " << endl << query << endl;

}

//void nsQuery (int freq) {
//	//NsQuery class for querying
//	//Database class for accessing the DB and logging time + latency
//	while (true) {
//		//start a timer for NsQuery
//		srand (time(NULL));
//		std::string server = std::to_string(rand() % 100) + ".www.google.com";
//		int latency = NsQuery(server);
//		std::time_t time = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
//		cout << "Latency for " << server << ": " << latency << endl;
//		
//		//log the results of NsQuery 
//		NsLog(time, latency);
//
//		//sleep for "freq" seconds
//		std::this_thread::sleep_for(std::chrono::seconds(freq));
//	}
//
//}
#endif 
/*
int NsLogClearDb(void);
int NsLogStats (void); 
int NsLog (std::time_t time, int latency);
void nsQuery (int freq);

*/
