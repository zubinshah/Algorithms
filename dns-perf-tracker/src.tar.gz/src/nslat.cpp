// zubin.shah@gmail.com
// 2018 - nslat utility to perform dns queries

#include <string.h>
#include "nslat.h"
#include "nsQuery.h"

void nslat_usage (void) {
#define NSLATENCY_COMMAND "nslat COMMAND [OPTION]"
#define NSLATENCY_DESCRIPTION "Nslat is a program to periodically sends DNS queries to the name servers of the top 10 sites on the web (according to Alexa) and store the latency values in a MySQL table. The frequency of queries should be specified by the user on command line. Besides the time series values, it keeps track of some statistics about each domain in the MySQL database."
	cout << "NAME" << endl;
	cout << "\tnslat - query top 10 name servers to measure their performance" << endl << endl;
	cout << "SYNOPSIS" << endl;
	cout << "\t" << NSLATENCY_COMMAND << endl << endl;
	cout << "DESCRIPTION" << endl;
	cout << NSLATENCY_DESCRIPTION << endl << endl;
	cout << "ARGUMENTS" << endl;
	cout << "\tnslat start (freq)" << endl;
	cout << "\tnslat stop" << endl;
	cout << "\tnslat cleardb" << endl;
	cout << "\tnslat stats" << endl;
	cout << endl << endl;
}

bool debug_mode = false;
//class ParseInput {
//	
//
//};

/*
//TODO
1. move the command parsing logic to its class 
2.test input string for number to string conversions
*/
int 
main(int argc, char *argv[]) {
	char * command = NULL;
	int freq = NSLATENCY_FREQ_DEFAULT;
	NsLatCmd cmd = Invalid;

	if (argc != 3 && argc != 2) {
		nslat_usage();
		return -1;
	}

	std::vector <std::string> serv;

	serv.push_back("www.google.com");
	serv.push_back("www.youtube.com");
	serv.push_back("www.facebook.com");
	serv.push_back("www.baidu.com");
	serv.push_back("www.wikipedia.com");
	serv.push_back("www.yahoo.com");
	serv.push_back("www.google.co.in");
	serv.push_back("www.reddit.com");
	serv.push_back("www.qq.com");
	serv.push_back("www.taobao.com");

	nsQuery nsq(serv, "localhost");

	//check the command 
	command = argv[1];
	if (strcmp (command, NSLATENCY_CMD_STR_START) == 0) {
		//nslat arguments check 
		if (argc == 3) {
			stringstream freqText (argv[2]);
			if ( !(freqText >> freq) ) {
				nslat_usage();
				return -1;
			}
			if (debug_mode) {
				cout << "start with freq: " << freq << endl;
			}
		} 
		cmd = Start;
		if (debug_mode) {
			cout << "command : nslat start " << freq << endl;
		}
		nsq.nsDoquery(freq);
	} else if (strcmp (command, NSLATENCY_CMD_STR_STOP) == 0) {
		if (debug_mode) {
			cout << "command : nslat stop: " << freq << endl;
		}
		cmd = Stop;
		//TBD : this is needed when doQuery is moved to daemon mode
	} else if (strcmp (command, NSLATENCY_CMD_STR_CLEARDB) == 0) {
		if (debug_mode) {
			cout << "command : nslat cleardb: " << freq << endl;
		}
		cmd = Cleardb;
		nsq.nsDbClear();
	} else if (strcmp (command, NSLATENCY_CMD_STR_STATS) == 0) {
		if (debug_mode) {
			cout << "command : nslat stats: " << freq << endl;
		}
		cmd = Stats;
		nsq.nsDbStats();
	} else {
		nslat_usage();
		return -1;
	}
	return 0;
}
